import numpy as np 
import pandas as pd
import requests 
import xlsxwriter
import math
from secrets import IEX_CLOUD_API_TOKEN #API key 

#import list of stock tickers into a pandas series
stocks = pd.read_csv('sp_500_stocks.csv')

stocks= stocks.drop(index=484) #the IEX Cloud API no longer supports data for 'WLTW' at index 184

#initialize pandas data frame 
my_columns = ['Ticker', 'Stock Price', 'Market Capitalization', 'Number of Shares to Buy']
final_dataframe = pd.DataFrame(columns = my_columns) 


#Use batch API calls to import data into a DataFrame

# Function sourced from 
# https://stackoverflow.com/questions/312443/how-do-you-split-a-list-into-evenly-sized-chunks
def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


symbol_groups = list(chunks(stocks['Ticker'], 100)) #split list of stocks into blocks of 100 for batch API calls
symbol_strings = [] #empty list to add ticker strings for API calls

for i in range(0, len(symbol_groups)):
    symbol_strings.append(','.join(symbol_groups[i])) #creates one large list of ticker strings seperated by commas


for symbol_string in symbol_strings:
    batch_api_call_url = f'https://sandbox.iexapis.com/stable/stock/market/batch/?types=quote&symbols={symbol_string}&token={IEX_CLOUD_API_TOKEN}'
    data = requests.get(batch_api_call_url).json() #data stored in dictionary, with the first key being quote
    for symbol in symbol_string.split(','): #splits ticker strings by comma
        final_dataframe = final_dataframe.append(
        pd.Series(
            [
                symbol,
                data[symbol]['quote']['latestPrice'],
                data[symbol]['quote']['marketCap'],
                'N/A'
            ],
        index = my_columns),
            ignore_index = True
        )


#Calculating the Number of Shares to Buy
portfolio_size = input('Enter the value of your portfolio:')
valid = False
while not valid:
    try:
        val = float(portfolio_size)
        print(val)
        valid=True
        
    except ValueError:
        print('That is not an integer! \nPlease try again:')
        portfolio_size = input('Enter the value of your portfolio:')

position_size = val/len(final_dataframe.index)
for i in range(0, len(final_dataframe.index)): #import into DataFrame
    final_dataframe.loc[i, 'Number of Shares to Buy'] = math.floor(position_size/final_dataframe.loc[i, 'Stock Price'])


#Formatting Our Excel Output
writer = pd.ExcelWriter('recommended trades.xlsx', engine='xlsxwriter')
final_dataframe.to_excel(writer, 'Recommended Trades', index=False)

background_color= '#293240'
font_color = '#ffffff'

string_format =writer.book.add_format(
    {
        'font_color': font_color,
        'bg_color': background_color,
        'border': 1
    }
)

dollar_format =writer.book.add_format(
    {
        'num_format': '$0.00',
        'font_color': font_color,
        'bg_color': background_color,
        'border': 1
    }
)

integer_format =writer.book.add_format(
    {
        'num_format': '0',
        'font_color': font_color,
        'bg_color': background_color,
        'border': 1
    }
)
column_format = {
    'A':['Ticker', string_format],
    'B':['Stock Price', dollar_format],
    'C':['Market Capitalization', dollar_format],
    'D':['Number of Shares to Buy', integer_format]
}

for column in column_format.keys():
    writer.sheets["Recommended Trades"].set_column(f'{column}:{column}', 23, column_format[column][1] )
    writer.sheets["Recommended Trades"].write(f'{column}1', column_format[column][0], string_format )

writer.save()